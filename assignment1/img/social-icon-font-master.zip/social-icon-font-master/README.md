![image](https://f.cloud.github.com/assets/436120/1600550/1bd250d4-5373-11e3-8a3b-87a00fbbd6b2.png)

A simple social icon web font featuring 51 glyphs, ready to roll or freely customise for your needs.

The SVG source files are included so you can create your own set or additions and generate new font files with [FontCustom.](https://github.com/FontCustom/fontcustom)

[Check out a preview here](http://tombryan.co/icon-font).

### Included Glyphs
AIM, Amazon, App Store, Basecamp, Behance, Blogger, Cargo, CloudApp, Creative Commons, Delicious, Designmoo, Digg, Dribbble, Dropbox, Email, Envato, Etsy, Evernote, Facebook, Flickr, Forrst, Foursquare, GitHub, Goodreads, Google+, Instagram, Instapaper, LinkedIn, Path, PayPal, Pinboard, Pinterest, Quora, Readernaut, Reddit, RSS, Skype, SoundCloud, Spotify Squarespace, Tumblr, Twitter, Vimeo, VSCO Grid, Wikipedia, WordPress, Xbox Live, Yahoo! Messenger, YouTube, Zerply, and Zootool.

### License
This font is licensed under the SIL Open Font License (OFL), Version 1.1